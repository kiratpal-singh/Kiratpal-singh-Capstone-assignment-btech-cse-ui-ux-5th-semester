"""Reporting: text tables + labelled charts (matplotlib, headless)."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs")

def table(headers, rows):
    rows = [[str(c) for c in r] for r in rows]
    w = [max(len(h), *(len(r[i]) for r in rows)) for i, h in enumerate(headers)]
    line = "+" + "+".join("-" * (x + 2) for x in w) + "+"
    fmt = lambda r: "| " + " | ".join(c.ljust(w[i]) for i, c in enumerate(r)) + " |"
    return "\n".join([line, fmt(headers), line, *map(fmt, rows), line])

def gantt_text(g):
    return " ".join(f"|{pid}:{s}-{e}" for pid, s, e in g) + "|"

def sched_table(results):
    return table(["Algorithm", "Avg WT", "Avg TAT", "Avg RT", "CPU %", "Thr/unit"],
                 [[n, f"{r['avg_waiting']:.2f}", f"{r['avg_turnaround']:.2f}", f"{r['avg_response']:.2f}",
                   f"{r['cpu_util']:.1f}", f"{r['throughput']:.3f}"] for n, r in results.items()])

def paging_table(cmp):
    algos = list(next(iter(cmp.values())).keys())
    return table(["Frames", *[f"{a} faults" for a in algos]],
                 [[f, *[cmp[f][a]["faults"] for a in algos]] for f in cmp])

def disk_table(results):
    return table(["Algorithm", "Total head movement", "Service order"],
                 [[n, r["total_movement"], " ".join(map(str, r["order"]))] for n, r in results.items()])

def _save(fig, name):
    os.makedirs(OUT, exist_ok=True)
    p = os.path.join(OUT, name)
    fig.tight_layout(); fig.savefig(p, dpi=130); plt.close(fig)
    return p

def chart_gantt(results):
    fig, axes = plt.subplots(len(results), 1, figsize=(9, 1.4 * len(results) + 1), sharex=True)
    pids = sorted({pid for r in results.values() for pid, _, _ in r["gantt"]})
    cmap = {p: plt.cm.tab10(i % 10) for i, p in enumerate(pids)}
    for ax, (name, r) in zip(axes, results.items()):
        for pid, s, e in r["gantt"]:
            ax.barh(0, e - s, left=s, color=cmap[pid], edgecolor="white")
            if e - s >= 2: ax.text((s + e) / 2, 0, pid, ha="center", va="center", fontsize=7, color="white")
        ax.set_yticks([]); ax.set_ylabel(name, rotation=0, ha="right", va="center", fontsize=8)
    axes[-1].set_xlabel("Time units"); axes[0].set_title("CPU scheduling Gantt charts")
    return _save(fig, "gantt_comparison.png")

def chart_sched(results):
    names = list(results); x = range(len(names)); w = 0.27
    fig, ax = plt.subplots(figsize=(8, 4))
    for k, (key, lab) in enumerate([("avg_waiting", "Waiting"), ("avg_turnaround", "Turnaround"), ("avg_response", "Response")]):
        ax.bar([i + (k - 1) * w for i in x], [results[n][key] for n in names], w, label=lab)
    ax.set_xticks(list(x)); ax.set_xticklabels(names); ax.set_ylabel("Average time units")
    ax.set_title("Scheduling algorithm comparison"); ax.legend()
    return _save(fig, "scheduler_metrics.png")

def chart_paging(cmp):
    frames = list(cmp); fig, ax = plt.subplots(figsize=(7, 4))
    for a in next(iter(cmp.values())):
        ax.plot(frames, [cmp[f][a]["faults"] for f in frames], marker="o", label=a)
    ax.set_xlabel("Number of frames"); ax.set_ylabel("Page faults"); ax.set_xticks(frames)
    ax.set_title("Page faults vs. frame count"); ax.legend()
    return _save(fig, "page_faults.png")

def chart_disk(results, head):
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4))
    names = list(results)
    a1.bar(names, [results[n]["total_movement"] for n in names], color="tab:blue")
    a1.set_ylabel("Total head movement (cylinders)"); a1.set_title("Disk scheduling comparison")
    for n in ("FCFS", "SCAN"):
        if n in results:
            path = [head] + results[n]["order"]
            a2.plot(range(len(path)), path, marker="o", label=n)
    a2.set_xlabel("Step"); a2.set_ylabel("Cylinder"); a2.set_title("Head path"); a2.legend()
    return _save(fig, "disk_scheduling.png")
