#!/usr/bin/env bash
# Prints a short host resource snapshot (used by the Python "Reporting" module).
set -u
echo "Host: $(uname -srm)"
echo "Load average: $(cut -d' ' -f1-3 /proc/loadavg 2>/dev/null || echo n/a)"
if [ -r /proc/meminfo ]; then
  awk '/MemTotal/{t=$2} /MemAvailable/{a=$2} END{printf "Memory: %.0f MB total, %.0f MB available (%.1f%% used)\n", t/1024, a/1024, (t-a)*100/t}' /proc/meminfo
fi
echo "Disk (/): $(df -h / 2>/dev/null | awk 'NR==2{print $3" used of "$2" ("$5")"}')"
echo "Processes running: $(ps -e --no-headers 2>/dev/null | wc -l)"
