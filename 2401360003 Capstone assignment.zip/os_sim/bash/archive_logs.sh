#!/usr/bin/env bash
# Rotates logs/activity.log into a timestamped archive (storage-management helper).
set -eu
cd "$(dirname "$0")/.."
mkdir -p logs/archive
if [ -s logs/activity.log ]; then
  cp logs/activity.log "logs/archive/activity_$(date +%Y%m%d_%H%M%S).log"
  echo "Archived $(wc -l < logs/activity.log) log lines."
else
  echo "Nothing to archive."
fi
