# OS Resource-Management Simulator (OSRMS)

An integrated **Python + Bash** application that simulates five operating-system resource-management functions
and compares algorithm performance with tables and labelled charts.

| Module | File | Algorithms |
|---|---|---|
| Process scheduling | `osim/scheduler.py` | FCFS, SJF, SRTF, Priority, Round Robin |
| Memory | `osim/memory.py` | FIFO / LRU / Optimal page replacement; first/best/worst-fit allocation |
| Deadlock | `osim/deadlock.py` | Banker's safety + resource-request, wait-for-graph cycle detection |
| Storage | `osim/storage.py` | FCFS, SSTF, SCAN, C-SCAN, LOOK disk scheduling |
| Reporting | `osim/report.py`, `bash/sysinfo.sh` | tables, Gantt/bar/line charts, live host snapshot |

**Bash integration:** `bash/sysinfo.sh` (host memory/disk/load), `bash/collect_procs.sh` (turns *real* `ps` output into a
scheduler dataset), `bash/archive_logs.sh` (log rotation), and `run.sh` (launcher). Python calls them through `osim/bash_bridge.py`.

## Requirements
Linux/macOS/WSL, Python 3.9+, Bash, `matplotlib` (`pip install matplotlib`). No other dependencies.

## Execution steps
```bash
chmod +x run.sh bash/*.sh
./run.sh menu     # interactive menu (default)
./run.sh demo     # run all modules on sample data -> outputs/demo_trace.txt + charts
./run.sh test     # 28 unit tests -> outputs/test_results.txt
./run.sh all      # demo + tests + log archive
```
Menu: `1` CPU scheduling · `2` Memory · `3` Banker's · `4` Disk · `5` Live system report (Bash) · `6` Run all · `0` Exit.

## Sample input (`data/`)
| File | Format |
|---|---|
| `processes.csv` | `pid,arrival,burst,priority` |
| `pages.txt` | space-separated page reference string |
| `banker.json` | `allocation`, `max`, `available` matrices |
| `disk_requests.txt` | space-separated cylinders (0–199) |
| `memory_blocks.txt` | `blocks:` and `requests:` lines |

## Outputs (`outputs/`)
`demo_trace.txt`, `menu_session_trace.txt`, `test_results.txt`, charts (`gantt_comparison.png`, `scheduler_metrics.png`,
`page_faults.png`, `disk_scheduling.png`), `screenshot_*.png`; activity log in `logs/activity.log`.

## Validation & reliability
Every input path goes through `osim/validators.py` and raises `ValidationError` (non-numeric, negative, out-of-range,
empty, duplicate PIDs, malformed CSV/JSON, missing files, bad Banker matrices). The menu catches errors and keeps running;
all actions are logged with timestamps. See `docs/REPORT.md` for the test matrix.

## Layout
```
main.py  run.sh  osim/  bash/  data/  tests/  outputs/  logs/  docs/REPORT.md
```

## Windows quick start
1. Install Python 3 and select **Add Python to PATH**.
2. Extract this ZIP completely.
3. Open the `os_sim` folder.
4. Double-click `SETUP_WINDOWS.bat` once to install dependencies.
5. Double-click `RUN_WINDOWS.bat` to start the menu.

You can also use `RUN_WINDOWS.bat demo` or `RUN_WINDOWS.bat test`.
The Python simulations work on Windows. Bash helper scripts require Git Bash or WSL.
