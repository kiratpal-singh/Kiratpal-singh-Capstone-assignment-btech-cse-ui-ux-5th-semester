@echo off
setlocal
cd /d "%~dp0"
if not exist outputs mkdir outputs
if not exist logs mkdir logs
where py >nul 2>nul
if %errorlevel%==0 (set PY=py -3) else (set PY=python)
%PY% -c "import matplotlib" >nul 2>nul
if errorlevel 1 (
  echo Required library Matplotlib is missing.
  echo First run SETUP_WINDOWS.bat
  pause
  exit /b 1
)
if "%~1"=="" goto menu
if /i "%~1"=="menu" goto menu
if /i "%~1"=="demo" goto demo
if /i "%~1"=="test" goto test
echo Usage: RUN_WINDOWS.bat [menu^|demo^|test]
pause
exit /b 2
:menu
%PY% main.py
goto end
:demo
%PY% main.py --demo
goto end
:test
%PY% -m unittest discover -s tests -v
goto end
:end
pause
